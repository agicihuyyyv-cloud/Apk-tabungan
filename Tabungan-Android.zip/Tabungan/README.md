# Tabungan (Android)

Aplikasi tabungan: banyak target, setor/tarik, progres, riwayat, mode gelap. Kotlin + Jetpack Compose, data disimpan lokal.

## Login
Masuk dengan nama + password (tanpa Google/Gmail). Akun disimpan lokal di HP, data tabungan dipisah per akun.
Ada akun developer bawaan dengan nama `dev` (password diberikan terpisah, di kode hanya hash-nya).

## Build APK
1. Buka folder ini di Android Studio (Hedgehog atau lebih baru). Tunggu Gradle sync selesai; SDK 34 akan diminta kalau belum ada.
2. Coba di emulator/HP: tombol Run.
3. Bikin APK: Build > Build APK(s). Hasil: app/build/outputs/apk/debug/app-debug.apk
4. APK rilis untuk Play Store: Build > Generate Signed App Bundle / APK.

Lewat terminal (opsional): jalankan `gradle wrapper --gradle-version 8.7` sekali, lalu `./gradlew assembleDebug`.

Ikon aplikasi masih bawaan. Ganti lewat klik kanan res > New > Image Asset.
