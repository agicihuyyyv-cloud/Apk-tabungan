package com.example.tabungan

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val Coin = Color(0xFFF0B429)

@Composable
private fun panelColors() =
    CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)

@Composable
fun TabunganApp(vm: SavingsViewModel = viewModel()) {
    val user = vm.user
    if (user == null) {
        LoginScreen(onLogin = vm::login, onRegister = vm::register)
    } else {
        HomeScreen(vm, user)
    }
}

@Composable
fun LoginScreen(onLogin: (String, String) -> String?, onRegister: (String, String) -> String?) {
    var registerMode by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "Tabungan",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(top = 48.dp)
            )
            Text(if (registerMode) "Buat akun baru dengan nama dan password." else "Masuk dengan nama dan password.")
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(20) },
                label = { Text("Nama") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = password,
                onValueChange = { password = it.take(64) },
                label = { Text("Password") },
                singleLine = true,
                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth()
            )
            TextButton(onClick = { showPassword = !showPassword }) {
                Text(if (showPassword) "Sembunyikan password" else "Lihat password")
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = {
                    error = if (registerMode) onRegister(name, password) else onLogin(name, password)
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (registerMode) "Daftar" else "Masuk") }
            TextButton(onClick = { registerMode = !registerMode; error = null }) {
                Text(if (registerMode) "Sudah punya akun? Masuk" else "Belum punya akun? Daftar")
            }
        }
    }
}

@Composable
fun HomeScreen(vm: SavingsViewModel, user: String) {
    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Masuk sebagai $user")
                    TextButton(onClick = { vm.logout() }) { Text("Keluar") }
                }
            }
            item { TotalCard(vm.goals.sumOf { it.saved }, vm.goals.size) }
            item { NewGoalCard(onAdd = vm::addGoal) }
            if (vm.goals.isEmpty()) {
                item {
                    Text(
                        "Belum ada tabungan. Isi nama dan target di atas untuk mulai.",
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
            items(vm.goals, key = { it.id }) { goal ->
                GoalCard(goal, onMove = vm::move, onDelete = { vm.delete(goal.id) })
            }
        }
    }
}

@Composable
fun TotalCard(total: Long, count: Int) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(24.dp)) {
            Text("Total tabungan")
            Text(
                rupiah(total),
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold
            )
            Text(if (count == 0) "Belum ada tabungan" else "dari $count tabungan")
        }
    }
}

@Composable
fun NewGoalCard(onAdd: (String, Long) -> Boolean) {
    var name by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Card(colors = panelColors(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Tabungan baru", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(40) },
                label = { Text("Nama tabungan") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = target,
                onValueChange = { target = formatInput(it) },
                label = { Text("Target (Rp)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = {
                    if (onAdd(name, parseInput(target))) {
                        name = ""
                        target = ""
                        error = null
                    } else {
                        error = "Isi nama dan target lebih dari 0."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Buat tabungan") }
        }
    }
}

@Composable
fun GoalCard(goal: Goal, onMove: (Long, Long) -> String?, onDelete: () -> Unit) {
    var amount by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var showHistory by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val dateFmt = remember { SimpleDateFormat("d MMM yyyy", Locale("id", "ID")) }
    val progress = (goal.saved.toFloat() / goal.target).coerceIn(0f, 1f)
    val left = goal.target - goal.saved

    Card(colors = panelColors(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    goal.name,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "${(progress * 100).toInt()}%",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            LinearProgressIndicator(
                progress = { progress },
                color = Coin,
                trackColor = MaterialTheme.colorScheme.background,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(12.dp)
                    .clip(RoundedCornerShape(6.dp))
            )
            Text("${rupiah(goal.saved)} dari ${rupiah(goal.target)}")
            Text(
                if (left > 0) "Kurang ${rupiah(left)}" else "Target tercapai!",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = if (left > 0) FontWeight.Normal else FontWeight.Bold
            )
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = formatInput(it) },
                label = { Text("Jumlah (Rp)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        error = onMove(goal.id, parseInput(amount))
                        if (error == null) amount = ""
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Setor") }
                OutlinedButton(
                    onClick = {
                        error = onMove(goal.id, -parseInput(amount))
                        if (error == null) amount = ""
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Tarik") }
            }
            TextButton(onClick = { showHistory = !showHistory }) {
                Text(if (showHistory) "Sembunyikan riwayat" else "Lihat riwayat")
            }
            if (showHistory) {
                if (goal.history.isEmpty()) Text("Belum ada transaksi.")
                goal.history.takeLast(8).reversed().forEach { t ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${if (t.amount > 0) "Setor" else "Tarik"}, ${dateFmt.format(Date(t.time))}")
                        Text("${if (t.amount > 0) "+" else "-"}${rupiah(abs(t.amount))}")
                    }
                }
            }
            TextButton(onClick = { if (confirmDelete) onDelete() else confirmDelete = true }) {
                Text(if (confirmDelete) "Yakin hapus? Ketuk lagi" else "Hapus tabungan")
            }
        }
    }
}
