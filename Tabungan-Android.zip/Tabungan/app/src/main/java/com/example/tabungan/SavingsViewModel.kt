package com.example.tabungan

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

class SavingsViewModel(app: Application) : AndroidViewModel(app) {
    private val auth = AuthStore(app)
    private val store = Store(app)

    var user by mutableStateOf(auth.currentUser())
        private set

    var goals by mutableStateOf(user?.let { store.load(it) } ?: emptyList())
        private set

    /** Mengembalikan pesan error, atau null jika berhasil. */
    fun login(name: String, password: String): String? {
        val error = auth.login(name, password)
        if (error == null) enter()
        return error
    }

    /** Mengembalikan pesan error, atau null jika berhasil. */
    fun register(name: String, password: String): String? {
        val error = auth.register(name, password)
        if (error == null) enter()
        return error
    }

    fun logout() {
        auth.logout()
        user = null
        goals = emptyList()
    }

    private fun enter() {
        user = auth.currentUser()
        goals = user?.let { store.load(it) } ?: emptyList()
    }

    fun addGoal(name: String, target: Long): Boolean {
        if (name.isBlank() || target <= 0) return false
        update { listOf(Goal(System.currentTimeMillis(), name.trim(), target)) + it }
        return true
    }

    /** amount positif = setor, negatif = tarik. Mengembalikan pesan error, atau null jika berhasil. */
    fun move(id: Long, amount: Long): String? {
        val goal = goals.find { it.id == id } ?: return "Tabungan tidak ditemukan."
        if (amount == 0L) return "Masukkan jumlah lebih dari 0."
        if (goal.saved + amount < 0) return "Saldo hanya ${rupiah(goal.saved)}."
        val tx = Tx(amount, System.currentTimeMillis())
        update { list ->
            list.map {
                if (it.id == id) it.copy(saved = it.saved + amount, history = it.history + tx) else it
            }
        }
        return null
    }

    fun delete(id: Long) = update { list -> list.filterNot { it.id == id } }

    private fun update(block: (List<Goal>) -> List<Goal>) {
        val u = user ?: return
        goals = block(goals)
        store.save(u, goals)
    }
}
