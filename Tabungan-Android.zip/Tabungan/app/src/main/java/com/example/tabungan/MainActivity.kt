package com.example.tabungan

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TabunganTheme {
                TabunganApp()
            }
        }
    }
}

@Composable
fun TabunganTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Color(0xFF5CC9AF),
            onPrimary = Color(0xFF08201A),
            background = Color(0xFF0D1C19),
            onBackground = Color(0xFFE6F0EC),
            surface = Color(0xFF0D1C19),
            onSurface = Color(0xFFE6F0EC),
            surfaceVariant = Color(0xFF152A26),
            onSurfaceVariant = Color(0xFFE6F0EC)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF0F5C4D),
            onPrimary = Color.White,
            background = Color(0xFFEDF2EF),
            onBackground = Color(0xFF10302A),
            surface = Color(0xFFEDF2EF),
            onSurface = Color(0xFF10302A),
            surfaceVariant = Color.White,
            onSurfaceVariant = Color(0xFF10302A)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
