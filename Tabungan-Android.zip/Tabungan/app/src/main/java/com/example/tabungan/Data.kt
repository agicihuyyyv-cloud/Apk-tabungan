package com.example.tabungan

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import java.text.NumberFormat
import java.util.Locale

/** amount positif = setor, negatif = tarik. */
data class Tx(val amount: Long, val time: Long)

data class Goal(
    val id: Long,
    val name: String,
    val target: Long,
    val saved: Long = 0,
    val history: List<Tx> = emptyList()
)

private val idLocale = Locale("id", "ID")

fun rupiah(n: Long): String = "Rp" + NumberFormat.getInstance(idLocale).format(n)

/** Ubah input mentah jadi angka berpemisah ribuan, contoh "5000000" -> "5.000.000". */
fun formatInput(s: String): String {
    val digits = s.filter(Char::isDigit).take(12)
    return if (digits.isEmpty()) "" else NumberFormat.getInstance(idLocale).format(digits.toLong())
}

fun parseInput(s: String): Long = s.filter(Char::isDigit).toLongOrNull() ?: 0L

/** Penyimpanan lokal sederhana (SharedPreferences + JSON). */
class Store(context: Context) {
    private val prefs = context.getSharedPreferences("tabungan", Context.MODE_PRIVATE)

    fun load(user: String): List<Goal> {
        val raw = prefs.getString("goals_$user", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                val h = o.getJSONArray("history")
                Goal(
                    id = o.getLong("id"),
                    name = o.getString("name"),
                    target = o.getLong("target"),
                    saved = o.getLong("saved"),
                    history = List(h.length()) { j ->
                        val t = h.getJSONObject(j)
                        Tx(t.getLong("amount"), t.getLong("time"))
                    }
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(user: String, goals: List<Goal>) {
        val arr = JSONArray()
        goals.forEach { g ->
            val h = JSONArray()
            g.history.forEach { t ->
                h.put(JSONObject().put("amount", t.amount).put("time", t.time))
            }
            arr.put(
                JSONObject()
                    .put("id", g.id)
                    .put("name", g.name)
                    .put("target", g.target)
                    .put("saved", g.saved)
                    .put("history", h)
            )
        }
        prefs.edit().putString("goals_$user", arr.toString()).apply()
    }
}

/**
 * Login lokal (tanpa server): nama + password. Password tidak pernah disimpan,
 * hanya hash PBKDF2 + salt. Data tabungan dipisah per akun.
 */
class AuthStore(context: Context) {
    private val prefs = context.getSharedPreferences("auth", Context.MODE_PRIVATE)

    private class Account(val name: String, val salt: String, val hash: String)

    // Akun developer bawaan. Yang tersimpan hanya hash-nya, bukan password.
    private val devAccount = Account(
        name = "dev",
        salt = "995130a91ca599e320849c7c30422e39",
        hash = "25f58f1becd5a24006b66a7dd44d5330c4724531"
    )

    private fun stored(): JSONArray =
        try { JSONArray(prefs.getString("accounts", "[]")) } catch (e: Exception) { JSONArray() }

    private fun accounts(): List<Account> {
        val list = mutableListOf(devAccount)
        val arr = stored()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(Account(o.getString("name"), o.getString("salt"), o.getString("hash")))
        }
        return list
    }

    private fun clean(name: String) = name.trim().lowercase()

    private fun hash(password: String, salt: String): String {
        val saltBytes = ByteArray(salt.length / 2) { salt.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        val spec = PBEKeySpec(password.toCharArray(), saltBytes, 10000, 160)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun currentUser(): String? = prefs.getString("current", null)

    /** Mengembalikan pesan error, atau null jika berhasil. */
    fun login(name: String, password: String): String? {
        val account = accounts().find { it.name == clean(name) }
        if (account == null || hash(password, account.salt) != account.hash) {
            return "Nama atau password salah."
        }
        prefs.edit().putString("current", account.name).apply()
        return null
    }

    /** Mengembalikan pesan error, atau null jika berhasil (langsung masuk). */
    fun register(name: String, password: String): String? {
        val n = clean(name)
        if (n.length < 3) return "Nama minimal 3 karakter."
        if (n.length > 20) return "Nama maksimal 20 karakter."
        if (password.length < 6) return "Password minimal 6 karakter."
        if (accounts().any { it.name == n }) return "Nama sudah dipakai."
        val saltBytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val salt = saltBytes.joinToString("") { "%02x".format(it) }
        val updated = stored().put(
            JSONObject().put("name", n).put("salt", salt).put("hash", hash(password, salt))
        )
        prefs.edit().putString("accounts", updated.toString()).putString("current", n).apply()
        return null
    }

    fun logout() {
        prefs.edit().remove("current").apply()
    }
}
